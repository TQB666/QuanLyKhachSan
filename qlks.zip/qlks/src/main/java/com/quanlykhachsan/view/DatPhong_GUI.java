/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package gui;

/**
 *
 * @author liemh
 */
public class DatPhong_GUI extends javax.swing.JPanel {

    /**
     * Creates new form DatPhong_GUI
     */
    public DatPhong_GUI() {
        initComponents();
    }

 
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        pLeft = new javax.swing.JPanel();
        lblDichVu = new javax.swing.JLabel();
        txtTenKhachHang = new javax.swing.JTextField();
        lblSoDienThoai = new javax.swing.JLabel();
        txtSoDienThoai = new javax.swing.JTextField();
        lblTTKhachHang = new javax.swing.JLabel();
        lblTTDichVu = new javax.swing.JLabel();
        lblTenKhachHang = new javax.swing.JLabel();
        comBoBoxDichVu = new javax.swing.JComboBox<>();
        lblGiaTB = new javax.swing.JLabel();
        txtGiaTB = new javax.swing.JTextField();
        lblTTThietBi = new javax.swing.JLabel();
        lblKhuVuc = new javax.swing.JLabel();
        lblGiaDV = new javax.swing.JLabel();
        comBoBoxThietBi = new javax.swing.JComboBox<>();
        txtGiaDichVu = new javax.swing.JTextField();
        lblTTKhuVuc = new javax.swing.JLabel();
        lblThietBi = new javax.swing.JLabel();
        comBoBoxKhuVuc = new javax.swing.JComboBox<>();
        btnThietBi = new javax.swing.JButton();
        btnDichVu = new javax.swing.JButton();
        btnKhuVuc = new javax.swing.JButton();
        pCenter = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jComboBox4 = new javax.swing.JComboBox<>();
        jLabel14 = new javax.swing.JLabel();
        jTextField5 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jTextField6 = new javax.swing.JTextField();
        jTextField7 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jTextField8 = new javax.swing.JTextField();
        jButton4 = new javax.swing.JButton();
        pCenter1 = new javax.swing.JPanel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        jTextField9 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jTextField10 = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jTextField11 = new javax.swing.JTextField();
        jLabel22 = new javax.swing.JLabel();
        jTextField12 = new javax.swing.JTextField();
        jLabel44 = new javax.swing.JLabel();
        scrollPaneDanhSach = new javax.swing.JScrollPane();
        pDSPhong = new javax.swing.JPanel();
        Phong01 = new javax.swing.JLabel();
        Phong02 = new javax.swing.JLabel();
        Phong03 = new javax.swing.JLabel();
        Phong04 = new javax.swing.JLabel();
        Phong05 = new javax.swing.JLabel();
        Phong06 = new javax.swing.JLabel();
        Phong07 = new javax.swing.JLabel();
        Phong08 = new javax.swing.JLabel();
        Phong09 = new javax.swing.JLabel();
        Phong10 = new javax.swing.JLabel();
        Phong11 = new javax.swing.JLabel();
        Phong12 = new javax.swing.JLabel();
        Phong13 = new javax.swing.JLabel();
        Phong14 = new javax.swing.JLabel();
        Phong15 = new javax.swing.JLabel();
        Phong16 = new javax.swing.JLabel();
        scrollPaneDanhSachHoaDon = new javax.swing.JScrollPane();
        jTable4 = new javax.swing.JTable();
        scrollPane = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        pRight = new javax.swing.JPanel();
        lblThanhToan = new javax.swing.JLabel();
        lblTienDV = new javax.swing.JLabel();
        jTextField13 = new javax.swing.JTextField();
        lblTienThietBi = new javax.swing.JLabel();
        txtTienPhong = new javax.swing.JTextField();
        lblTienPhong = new javax.swing.JLabel();
        txtTienThietBi = new javax.swing.JTextField();
        lblTienVoucher = new javax.swing.JLabel();
        txtTienVoucher = new javax.swing.JTextField();
        lblThue = new javax.swing.JLabel();
        lblTongTien = new javax.swing.JLabel();
        txtTongTien = new javax.swing.JTextField();
        btnThanhToan = new javax.swing.JButton();
        btnInHoaDon = new javax.swing.JButton();

        lblDichVu.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblDichVu.setText("Dịch vụ");

        txtTenKhachHang.setText("jTextField1");
        txtTenKhachHang.setEnabled(false);

        lblSoDienThoai.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblSoDienThoai.setText("Số điện thoại");

        txtSoDienThoai.setText("jTextField1");

        lblTTKhachHang.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        lblTTKhachHang.setText("Khách hàng");

        lblTTDichVu.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        lblTTDichVu.setText("Dịch vụ");

        lblTenKhachHang.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTenKhachHang.setText("Tên khách hàng");

        comBoBoxDichVu.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        lblGiaTB.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblGiaTB.setText("Giá");

        txtGiaTB.setText("jTextField1");
        txtGiaTB.setEnabled(false);

        lblTTThietBi.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        lblTTThietBi.setText("Thiết bị");

        lblKhuVuc.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblKhuVuc.setText("Khu vực");

        lblGiaDV.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblGiaDV.setText("Giá");

        comBoBoxThietBi.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        txtGiaDichVu.setText("jTextField1");
        txtGiaDichVu.setEnabled(false);

        lblTTKhuVuc.setFont(new java.awt.Font("Arial", 0, 16)); // NOI18N
        lblTTKhuVuc.setText("Khu vực");

        lblThietBi.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblThietBi.setText("Thiết bị");

        comBoBoxKhuVuc.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btnThietBi.setText("Thêm thiết bị");

        btnDichVu.setText("Thêm dịch vụ");

        btnKhuVuc.setText("Thêm khu vực");

        javax.swing.GroupLayout pLeftLayout = new javax.swing.GroupLayout(pLeft);
        pLeft.setLayout(pLeftLayout);
        pLeftLayout.setHorizontalGroup(
            pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pLeftLayout.createSequentialGroup()
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pLeftLayout.createSequentialGroup()
                        .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pLeftLayout.createSequentialGroup()
                                .addComponent(lblThietBi)
                                .addGap(18, 18, 18))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pLeftLayout.createSequentialGroup()
                                .addComponent(lblGiaTB)
                                .addGap(33, 33, 33))
                            .addGroup(pLeftLayout.createSequentialGroup()
                                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(pLeftLayout.createSequentialGroup()
                                        .addGap(21, 21, 21)
                                        .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                            .addComponent(lblDichVu)
                                            .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(lblSoDienThoai)
                                                .addComponent(lblTenKhachHang))
                                            .addComponent(lblGiaDV)))
                                    .addGroup(pLeftLayout.createSequentialGroup()
                                        .addContainerGap()
                                        .addComponent(lblTTKhuVuc)))
                                .addGap(31, 31, 31)))
                        .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txtTenKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtSoDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comBoBoxDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtGiaTB, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(comBoBoxThietBi, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(txtGiaDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(pLeftLayout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(lblTTKhachHang)
                            .addComponent(lblTTDichVu)
                            .addComponent(lblTTThietBi)))
                    .addGroup(pLeftLayout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(btnDichVu)
                        .addGap(18, 18, 18)
                        .addComponent(btnThietBi)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btnKhuVuc))
                    .addGroup(pLeftLayout.createSequentialGroup()
                        .addGap(88, 88, 88)
                        .addComponent(lblKhuVuc)
                        .addGap(18, 18, 18)
                        .addComponent(comBoBoxKhuVuc, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pLeftLayout.setVerticalGroup(
            pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pLeftLayout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addComponent(lblTTKhachHang)
                .addGap(18, 18, 18)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txtTenKhachHang, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblTenKhachHang))
                .addGap(18, 18, 18)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblSoDienThoai)
                    .addComponent(txtSoDienThoai, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(lblTTDichVu)
                .addGap(18, 18, 18)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblDichVu)
                    .addComponent(comBoBoxDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblGiaDV)
                    .addComponent(txtGiaDichVu, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(lblTTThietBi)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(comBoBoxThietBi, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lblThietBi))
                .addGap(18, 18, 18)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pLeftLayout.createSequentialGroup()
                        .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txtGiaTB, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(lblGiaTB))
                        .addGap(18, 18, 18))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pLeftLayout.createSequentialGroup()
                        .addComponent(lblTTKhuVuc)
                        .addGap(3, 3, 3)))
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblKhuVuc)
                    .addComponent(comBoBoxKhuVuc, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pLeftLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThietBi)
                    .addComponent(btnDichVu)
                    .addComponent(btnKhuVuc))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel12.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel12.setText("Thông tin phòng");

        jLabel13.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel13.setText("Phòng");

        jComboBox4.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        jComboBox4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jComboBox4ActionPerformed(evt);
            }
        });

        jLabel14.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel14.setText("Loại phòng");

        jTextField5.setText("jTextField5");
        jTextField5.setEnabled(false);

        jLabel15.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel15.setText("Giá");

        jTextField6.setText("jTextField5");

        jTextField7.setText("jTextField5");
        jTextField7.setEnabled(false);
        jTextField7.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jTextField7ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel16.setText("Check-in");

        jLabel17.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel17.setText("Check-out");

        jTextField8.setText("jTextField5");
        jTextField8.setEnabled(false);

        jButton4.setText("Thêm phòng");

        javax.swing.GroupLayout pCenterLayout = new javax.swing.GroupLayout(pCenter);
        pCenter.setLayout(pCenterLayout);
        pCenterLayout.setHorizontalGroup(
            pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCenterLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel12))
            .addGroup(pCenterLayout.createSequentialGroup()
                .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, pCenterLayout.createSequentialGroup()
                            .addContainerGap()
                            .addComponent(jLabel17))
                        .addGroup(pCenterLayout.createSequentialGroup()
                            .addGap(23, 23, 23)
                            .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(jLabel15)
                                .addComponent(jLabel16))))
                    .addGroup(pCenterLayout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel13)
                            .addComponent(jLabel14))))
                .addGap(28, 28, 28)
                .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
            .addGroup(pCenterLayout.createSequentialGroup()
                .addGap(53, 53, 53)
                .addComponent(jButton4))
        );
        pCenterLayout.setVerticalGroup(
            pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCenterLayout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel12)
                .addGap(18, 18, 18)
                .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(jTextField5, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCenterLayout.createSequentialGroup()
                        .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel14)
                            .addComponent(jComboBox4, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addComponent(jLabel15))
                    .addGroup(pCenterLayout.createSequentialGroup()
                        .addGap(43, 43, 43)
                        .addComponent(jTextField7, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jTextField8, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel16))))
                .addGap(18, 18, 18)
                .addGroup(pCenterLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17)
                    .addComponent(jTextField6, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(52, 52, 52)
                .addComponent(jButton4)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jLabel18.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel18.setText("Hóa đơn");

        jLabel19.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel19.setText("Mã hóa đơn");

        jTextField9.setText("jTextField5");
        jTextField9.setEnabled(false);

        jLabel20.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel20.setText("Giảm giá");

        jTextField10.setText("jTextField5");
        jTextField10.setEnabled(false);

        jLabel21.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel21.setText("Tên nhân viên");

        jTextField11.setText("jTextField5");
        jTextField11.setEnabled(false);

        jLabel22.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel22.setText("Thành tiền");

        jTextField12.setText("jTextField5");
        jTextField12.setEnabled(false);

        jLabel44.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        jLabel44.setText("Chi tiết hóa đơn");

        javax.swing.GroupLayout pCenter1Layout = new javax.swing.GroupLayout(pCenter1);
        pCenter1.setLayout(pCenter1Layout);
        pCenter1Layout.setHorizontalGroup(
            pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCenter1Layout.createSequentialGroup()
                .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pCenter1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jLabel18))
                    .addGroup(pCenter1Layout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addComponent(jLabel44))
                    .addGroup(pCenter1Layout.createSequentialGroup()
                        .addGap(30, 30, 30)
                        .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel19)
                            .addComponent(jLabel20)
                            .addComponent(jLabel21)
                            .addComponent(jLabel22))
                        .addGap(18, 18, 18)
                        .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(16, Short.MAX_VALUE))
        );
        pCenter1Layout.setVerticalGroup(
            pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pCenter1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(jTextField9, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(24, 24, 24)
                .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(jTextField11, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(27, 27, 27)
                .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jTextField10, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(pCenter1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel22)
                    .addComponent(jTextField12, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel44)
                .addGap(18, 18, 18))
        );

        Phong01.setText("Phòng 01");

        Phong02.setText("Phòng 02");

        Phong03.setText("Phòng 03");

        Phong04.setText("Phòng 04");

        Phong05.setText("Phòng 05");

        Phong06.setText("Phòng 06");

        Phong07.setText("Phòng 07 ");

        Phong08.setText("Phòng 08");

        Phong09.setText("Phòng 09");

        Phong10.setText("Phòng 10");

        Phong11.setText("Phòng 11");

        Phong12.setText("Phòng 12");

        Phong13.setText("Phòng 13");

        Phong14.setText("Phòng 15");

        Phong15.setText("Phòng 14");

        Phong16.setText("Danh sách phòng hiện có");

        javax.swing.GroupLayout pDSPhongLayout = new javax.swing.GroupLayout(pDSPhong);
        pDSPhong.setLayout(pDSPhongLayout);
        pDSPhongLayout.setHorizontalGroup(
            pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDSPhongLayout.createSequentialGroup()
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pDSPhongLayout.createSequentialGroup()
                        .addGap(22, 22, 22)
                        .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Phong05)
                            .addComponent(Phong04)
                            .addComponent(Phong03)
                            .addComponent(Phong02)
                            .addComponent(Phong01))
                        .addGap(34, 34, 34)
                        .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Phong08)
                            .addComponent(Phong07)
                            .addComponent(Phong09)
                            .addComponent(Phong10)
                            .addComponent(Phong06))
                        .addGap(41, 41, 41)
                        .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(Phong11)
                            .addComponent(Phong13)
                            .addComponent(Phong15)
                            .addComponent(Phong14)
                            .addComponent(Phong12)))
                    .addGroup(pDSPhongLayout.createSequentialGroup()
                        .addGap(86, 86, 86)
                        .addComponent(Phong16)))
                .addContainerGap(85, Short.MAX_VALUE))
        );
        pDSPhongLayout.setVerticalGroup(
            pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pDSPhongLayout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(Phong16)
                .addGap(49, 49, 49)
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Phong01, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong06, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong11, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Phong02, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong07, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong12, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Phong03, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong13, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong08, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Phong04, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong15, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong09, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(pDSPhongLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(Phong05, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong14, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(Phong10, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(253, Short.MAX_VALUE))
        );

        scrollPaneDanhSach.setViewportView(pDSPhong);

        jTable4.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Khách hàng", "Dịch vụ", "Thiết bị", "Phòng"
            }
        ));
        scrollPaneDanhSachHoaDon.setViewportView(jTable4);

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Khách hàng", "Số điện thoại", "Dịch vụ", "Số lượng dịch vụ", "Thiết bị", "Số lượng thiết bị", "Voucher", "Khu vực", "Phòng", "Giá phòng", "Nhân viên", "Tổng tiền"
            }
        ));
        scrollPane.setViewportView(jTable2);

        lblThanhToan.setFont(new java.awt.Font("Arial", 1, 18)); // NOI18N
        lblThanhToan.setText("Thanh toán");

        lblTienDV.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTienDV.setText("Tiền dịch vụ");

        jTextField13.setText("jTextField5");
        jTextField13.setEnabled(false);

        lblTienThietBi.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTienThietBi.setText("Tiền thiết bị");

        txtTienPhong.setText("jTextField5");
        txtTienPhong.setEnabled(false);

        lblTienPhong.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTienPhong.setText("Tiền phòng");

        txtTienThietBi.setText("jTextField5");
        txtTienThietBi.setEnabled(false);
        txtTienThietBi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtTienThietBiActionPerformed(evt);
            }
        });

        lblTienVoucher.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTienVoucher.setText("Tiền voucher");

        txtTienVoucher.setText("jTextField5");
        txtTienVoucher.setEnabled(false);

        lblThue.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblThue.setText("Thuế: 10%");

        lblTongTien.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        lblTongTien.setText("Tổng tiền");

        txtTongTien.setText("jTextField5");
        txtTongTien.setEnabled(false);

        btnThanhToan.setText("Thanh toán");

        btnInHoaDon.setText("In hóa đơn");

        javax.swing.GroupLayout pRightLayout = new javax.swing.GroupLayout(pRight);
        pRight.setLayout(pRightLayout);
        pRightLayout.setHorizontalGroup(
            pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRightLayout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(pRightLayout.createSequentialGroup()
                        .addComponent(btnThanhToan)
                        .addGap(18, 18, 18)
                        .addComponent(btnInHoaDon))
                    .addComponent(lblThue)
                    .addGroup(pRightLayout.createSequentialGroup()
                        .addComponent(lblTienDV)
                        .addGap(18, 18, 18)
                        .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(pRightLayout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(lblThanhToan)))
                    .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                        .addGroup(pRightLayout.createSequentialGroup()
                            .addComponent(lblTongTien)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pRightLayout.createSequentialGroup()
                            .addComponent(lblTienThietBi)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTienThietBi, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pRightLayout.createSequentialGroup()
                            .addComponent(lblTienPhong)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(txtTienPhong, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(pRightLayout.createSequentialGroup()
                            .addComponent(lblTienVoucher)
                            .addGap(18, 18, 18)
                            .addComponent(txtTienVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        pRightLayout.setVerticalGroup(
            pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(pRightLayout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblThanhToan)
                .addGap(12, 12, 12)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTienDV)
                    .addComponent(jTextField13, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(20, 20, 20)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTienThietBi)
                    .addComponent(txtTienThietBi, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTienPhong)
                    .addComponent(txtTienPhong, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(22, 22, 22)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTienVoucher)
                    .addComponent(txtTienVoucher, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addComponent(lblThue)
                .addGap(18, 18, 18)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(lblTongTien)
                    .addComponent(txtTongTien, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(36, 36, 36)
                .addGroup(pRightLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnThanhToan)
                    .addComponent(btnInHoaDon))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(pLeft, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pCenter, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPaneDanhSach, javax.swing.GroupLayout.PREFERRED_SIZE, 275, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pCenter1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(pRight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(scrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 1000, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(scrollPaneDanhSachHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 491, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 8, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(pLeft, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pCenter1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(pRight, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(scrollPaneDanhSach, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(pCenter, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(scrollPane, javax.swing.GroupLayout.DEFAULT_SIZE, 376, Short.MAX_VALUE)
                    .addComponent(scrollPaneDanhSachHoaDon, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
    }// </editor-fold>//GEN-END:initComponents

    private void jComboBox4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jComboBox4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jComboBox4ActionPerformed

    private void jTextField7ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jTextField7ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jTextField7ActionPerformed

    private void txtTienThietBiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtTienThietBiActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtTienThietBiActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Phong01;
    private javax.swing.JLabel Phong02;
    private javax.swing.JLabel Phong03;
    private javax.swing.JLabel Phong04;
    private javax.swing.JLabel Phong05;
    private javax.swing.JLabel Phong06;
    private javax.swing.JLabel Phong07;
    private javax.swing.JLabel Phong08;
    private javax.swing.JLabel Phong09;
    private javax.swing.JLabel Phong10;
    private javax.swing.JLabel Phong11;
    private javax.swing.JLabel Phong12;
    private javax.swing.JLabel Phong13;
    private javax.swing.JLabel Phong14;
    private javax.swing.JLabel Phong15;
    private javax.swing.JLabel Phong16;
    private javax.swing.JButton btnDichVu;
    private javax.swing.JButton btnInHoaDon;
    private javax.swing.JButton btnKhuVuc;
    private javax.swing.JButton btnThanhToan;
    private javax.swing.JButton btnThietBi;
    private javax.swing.JComboBox<String> comBoBoxDichVu;
    private javax.swing.JComboBox<String> comBoBoxKhuVuc;
    private javax.swing.JComboBox<String> comBoBoxThietBi;
    private javax.swing.JButton jButton4;
    private javax.swing.JComboBox<String> jComboBox4;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel44;
    private javax.swing.JTable jTable2;
    private javax.swing.JTable jTable4;
    private javax.swing.JTextField jTextField10;
    private javax.swing.JTextField jTextField11;
    private javax.swing.JTextField jTextField12;
    private javax.swing.JTextField jTextField13;
    private javax.swing.JTextField jTextField5;
    private javax.swing.JTextField jTextField6;
    private javax.swing.JTextField jTextField7;
    private javax.swing.JTextField jTextField8;
    private javax.swing.JTextField jTextField9;
    private javax.swing.JLabel lblDichVu;
    private javax.swing.JLabel lblGiaDV;
    private javax.swing.JLabel lblGiaTB;
    private javax.swing.JLabel lblKhuVuc;
    private javax.swing.JLabel lblSoDienThoai;
    private javax.swing.JLabel lblTTDichVu;
    private javax.swing.JLabel lblTTKhachHang;
    private javax.swing.JLabel lblTTKhuVuc;
    private javax.swing.JLabel lblTTThietBi;
    private javax.swing.JLabel lblTenKhachHang;
    private javax.swing.JLabel lblThanhToan;
    private javax.swing.JLabel lblThietBi;
    private javax.swing.JLabel lblThue;
    private javax.swing.JLabel lblTienDV;
    private javax.swing.JLabel lblTienPhong;
    private javax.swing.JLabel lblTienThietBi;
    private javax.swing.JLabel lblTienVoucher;
    private javax.swing.JLabel lblTongTien;
    private javax.swing.JPanel pCenter;
    private javax.swing.JPanel pCenter1;
    private javax.swing.JPanel pDSPhong;
    private javax.swing.JPanel pLeft;
    private javax.swing.JPanel pRight;
    private javax.swing.JScrollPane scrollPane;
    private javax.swing.JScrollPane scrollPaneDanhSach;
    private javax.swing.JScrollPane scrollPaneDanhSachHoaDon;
    private javax.swing.JTextField txtGiaDichVu;
    private javax.swing.JTextField txtGiaTB;
    private javax.swing.JTextField txtSoDienThoai;
    private javax.swing.JTextField txtTenKhachHang;
    private javax.swing.JTextField txtTienPhong;
    private javax.swing.JTextField txtTienThietBi;
    private javax.swing.JTextField txtTienVoucher;
    private javax.swing.JTextField txtTongTien;
    // End of variables declaration//GEN-END:variables
}
