package gui;

import javax.swing.JPanel;
import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.table.DefaultTableModel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ThietBi_GUI extends JPanel {

	private static final long serialVersionUID = 1L;
	private JTextField txtTenThietBi;
	private JTextField txtMaThietBi;
	private DefaultTableModel modelThietBi;
	private JTable tableThietBi;

	/**
	 * Create the panel.
	 */
	public ThietBi_GUI() {
				setLayout(null);
				setBounds(100, 100, 1056, 713);

				
				JPanel panel = new JPanel();
				panel.setBounds(10, 10, 1038, 36);
				add(panel);
				panel.setLayout(null);
				
				JLabel lblNewLabel = new JLabel("Quản Lý Thiết Bị");
				lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
				lblNewLabel.setFont(new Font("Times New Roman", Font.BOLD, 14));
				lblNewLabel.setBounds(0, 0, 1035, 36);
				panel.add(lblNewLabel);
				
				JPanel panel_1 = new JPanel();
				panel_1.setBounds(10, 56, 1038, 147);
				add(panel_1);
				panel_1.setLayout(null);
				
				JLabel lblNewLabel_1 = new JLabel("Mã Thiết Bị:");
				lblNewLabel_1.setBounds(10, 10, 92, 26);
				panel_1.add(lblNewLabel_1);
				
				JLabel lblNewLabel_2 = new JLabel("Tên Thiết Bị:");
				lblNewLabel_2.setBounds(10, 46, 92, 27);
				panel_1.add(lblNewLabel_2);
				
				JLabel lblNewLabel_3 = new JLabel("Trạng Thái");
				lblNewLabel_3.setBounds(10, 90, 92, 28);
				panel_1.add(lblNewLabel_3);
				
				JComboBox cbTrangThai = new JComboBox();
				cbTrangThai.setBounds(112, 86, 96, 32);
				panel_1.add(cbTrangThai);
				
				txtTenThietBi = new JTextField();
				txtTenThietBi.setBounds(112, 44, 96, 26);
				panel_1.add(txtTenThietBi);
				txtTenThietBi.setColumns(10);
				
				txtMaThietBi = new JTextField();
				txtMaThietBi.setEditable(false);
				txtMaThietBi.setEnabled(false);
				txtMaThietBi.setBounds(112, 7, 96, 25);
				panel_1.add(txtMaThietBi);
				txtMaThietBi.setColumns(10);
				
				JButton btnThem = new JButton("Thêm");
				btnThem.setBounds(235, 6, 85, 25);
				panel_1.add(btnThem);
				
				JButton btnTrangThai = new JButton("Thay đổi trạng thái");
				btnTrangThai.setBounds(356, 8, 137, 25);
				panel_1.add(btnTrangThai);
				
				JButton btnCapNhat = new JButton("Cập Nhật");
				btnCapNhat.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
					}
				});
				btnCapNhat.setBounds(235, 41, 85, 25);
				panel_1.add(btnCapNhat);
				
				JButton btnXoaTrang = new JButton("Xóa Trắng");
				btnXoaTrang.setBounds(356, 43, 137, 25);
				panel_1.add(btnXoaTrang);
				
				JPanel panel_2 = new JPanel();
				panel_2.setBounds(10, 208, 1038, 510);
				add(panel_2);
				panel_2.setLayout(null);
				
				JScrollPane scrollPane = new JScrollPane();
				scrollPane.setBounds(0, 20, 1040, 490);
				panel_2.add(scrollPane);
				
				String header[]= new String[] {"Mã Dịch Vụ","Tên Thiết Bị","Trạng Thái"};
				modelThietBi = new DefaultTableModel(header,0);
				tableThietBi = new JTable(modelThietBi);
				scrollPane.setViewportView(tableThietBi);
			}

	}

