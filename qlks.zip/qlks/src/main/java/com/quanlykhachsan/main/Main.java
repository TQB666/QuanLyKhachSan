/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.quanlykhachsan.main;



import com.quanlykhachsan.view.ThongKe_GUI;
import com.quanlykhachsan.view.TrangChu_GUI;
import javax.swing.JFrame;
import javax.swing.UIManager;
import javax.swing.WindowConstants;

/**
 *
 * @author nguye
 */
public class Main {
       public static void main(String[] args) {
           try {
               
               
           } catch (Exception e) {
           }
           JFrame test = new TrangChu_GUI();
           test.setVisible(true);
           test.setSize(1450, 800);
           test.setExtendedState(test.MAXIMIZED_BOTH);
           
    }
         
         
         
}   
